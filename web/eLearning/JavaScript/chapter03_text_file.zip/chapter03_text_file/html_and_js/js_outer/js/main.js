document.title = "JavaScriptで書き換え";
console.log("JavaScriptで出力");
