// コンソールに情報を出力
console.log("sub.js が読み込まれました。");
